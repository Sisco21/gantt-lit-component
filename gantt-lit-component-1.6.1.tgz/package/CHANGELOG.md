# Changelog

All notable changes to this project are documented in this file.

## [Unreleased]

### Added

- Optional detachable Resource panel with a synchronized, resizable secondary window.
- `resourcePanel` configuration, `undockResources()` / `dockResources()` APIs, and localized dock controls.

## [1.6.1] - 2026-10-09

### Fixed

- Ctrl/Cmd + wheel zoom now keeps the date under the pointer fixed, or keeps the timeline center when zooming from the task grid.

## [1.6.0] - 2026-10-09

### Added

- Dependency-arrow context menus through `dependencyContextMenuTemplate`, including targeted dependency context, viewport-safe positioning and keyboard opening with `ContextMenu` / `Shift+F10`.
- Incremental dependency removal remains available through `removeDependency(from, to)`, preserving the existing plan view and compatibility with 1.5.0 integrations.
- Unit and interaction coverage for dependency targeting, task-menu separation, cancellation, keyboard closing and incremental removal.

## [1.5.0] - 2026-10-09

### Added

- Visual calendar exceptions in the planning and resource grids, including accessible date/status titles and light/dark theme variables.
- `GanttData.projectCalendarId`, `GanttTask.calendarId` and `GanttCalendar.exceptionLabels`.
- Targeted `updateCalendar(calendar)` and `setProjectCalendarId(calendarId)` APIs that preserve selection, zoom and scroll state without recalculating business data.
- Automated coverage for holiday exceptions, worked weekend overrides, task/resource calendars and targeted visual updates.

## [1.4.0] - 2026-10-08

### Added

- Incremental task and resource APIs: `updateTask()`, `updateTaskResources()`, `updateResourceAssignment()`, `removeResourceAssignment()` and `refreshTask()`.
- Focused `task-updated` and `resource-assignment-updated` events with monotonic revisions and typed update reasons.
- `incrementalUpdates`, `recalculateOnMoveEnd` and `preserveScroll` configuration options.
- Documentation and test coverage for parent phase roll-ups, detached resources, scroll preservation and selection/editor-state preservation.

### Changed

- Targeted updates now reconcile only the affected task/assignment through the existing Lit render tree; `data` remains the full-load/import/reload API.
- Resource and schedule changes keep detached resource panels synchronized without requiring host-side full-data reinjection.

## [1.3.0] - 2026-10-08

### Added

- Optional deferred and controlled task move/resize scheduling through `scheduleEditing`.
- Schedule-edit lifecycle callbacks, controlled commit results and `isScheduleEditing()` / `cancelScheduleEdit()` APIs.

## [1.2.0] - 2026-10-07

### Added

- Native `select` editors for resource columns through `GanttResourceColumnEditor` and `GanttResourceColumnOption`.
- Disabled-option support and disabled fallbacks for resource values that are not present in the configured options.

### Changed

- Resource-column editors now accept explicit `text`, `number` and `select` types while preserving the 1.1.0 fallback behavior.

## [1.1.0] - 2026-09-10

### Added

- Public component version through `GANTT_COMPONENT_VERSION`, `GanttChart.version` and `gantt.version`.
- Configurable task and resource column layouts: resize, order, visibility and required columns.
- Column-layout persistence API: `getColumnSettings()`, `setColumnSettings()` and `resetColumnSettings()`.
- `columnSettings.onChange` and `columnSettings.onReset` hooks, plus `column-settings-changed` and `column-settings-reset` events.
- Independent column permissions: `allowResize`, `allowReorder` and `allowVisibility`.
- Hover-only six-dot drag handles and keyboard-accessible order controls in the Columns panel.
- Configurable task-row height, including a Columns-panel slider and persistence through `GanttColumnSettings.taskRowHeight`.
- Resource-column numeric types, increments, minimum values and custom metadata-backed columns.
- Built-in French and English labels for the latest grid and column controls.

### Changed

- Improved dark-theme contrast, timeline/resource-grid alignment and Gantt scrolling behaviour.
- Expanded documentation and demo coverage for external integrations, templates, themes, calendars, headers, tooltips and column settings.
- Package build now includes TypeScript declaration files and supports Git-based installation through `prepare`.

### Fixed

- Removed redundant Lit update scheduling from resource timeline measurement.
- Corrected Lit input bindings for numeric `step` values and header drag attributes.
- Corrected week-header rendering and grid separator alignment.

## [1.0.0] - 2026-09-08

### Added

- Initial reusable Lit Gantt component with task tree, dependencies, resource assignments, timeline editing, import/export and host integration hooks.
